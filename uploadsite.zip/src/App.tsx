import { useState } from 'react';
import { FileManager } from '@/components/file-manager';
import { Button } from '@/components/ui/button';
import { Cloud } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

function App() {
  const [isAboutOpen, setIsAboutOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* File Manager Section */}
      <section id="files" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="bg-card/50 backdrop-blur-sm border border-border rounded-2xl p-6 sm:p-8">
            <FileManager />
          </div>
        </div>
      </section>

      {/* About Dialog */}
      <Dialog open={isAboutOpen} onOpenChange={setIsAboutOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                <Cloud size={18} className="text-white" />
              </div>
              About FileVault
            </DialogTitle>
            <DialogDescription>
              A modern, dark-themed file manager for your browser
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              FileVault is a fully functional file management application that runs entirely 
              in your browser. It uses localStorage to persist your files and folders, 
              meaning your data never leaves your device.
            </p>
            
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Keyboard Shortcuts</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Ctrl/Cmd + U</span>
                  <span className="text-muted-foreground">Upload files</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Ctrl/Cmd + N</span>
                  <span className="text-muted-foreground">New folder</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Backspace</span>
                  <span className="text-muted-foreground">Go back</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Double-click</span>
                  <span className="text-muted-foreground">Open folder</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Supported File Types</h4>
              <p className="text-sm text-muted-foreground">
                Images, Videos, Audio, Documents, Archives, Code files, and more.
              </p>
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button onClick={() => setIsAboutOpen(false)}>Got it</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
