import { useEffect, useState, FormEvent } from 'react';
import { FileManager } from '@/components/file-manager';
import { Button } from '@/components/ui/button';
import { Cloud } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

type StoredHash = {
  hash: string;
  salt: string;
  iterations: number;
};

const AUTH_STORAGE_KEY = 'fv_auth_v1';

function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

async function hashPassword(
  password: string,
  existingSalt?: ArrayBuffer,
  iterations = 210_000,
): Promise<StoredHash> {
  const enc = new TextEncoder();
  const passwordKey = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    'PBKDF2',
    false,
    ['deriveBits'],
  );

  const saltBytes = existingSalt
    ? new Uint8Array(existingSalt)
    : crypto.getRandomValues(new Uint8Array(16));

  const params = {
    name: 'PBKDF2',
    hash: 'SHA-256',
    salt: saltBytes,
    iterations,
  } as const;

  const derivedBits = await crypto.subtle.deriveBits(
    params,
    passwordKey,
    256,
  );

  return {
    hash: bufferToBase64(derivedBits),
    salt: bufferToBase64(saltBytes.buffer),
    iterations,
  };
}

async function verifyPassword(password: string, stored: StoredHash): Promise<boolean> {
  const saltBuffer = base64ToArrayBuffer(stored.salt);
  const candidate = await hashPassword(password, saltBuffer, stored.iterations);
  return candidate.hash === stored.hash;
}

function App() {
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [hasPassword, setHasPassword] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [setupPassword, setSetupPassword] = useState('');
  const [setupConfirmPassword, setSetupConfirmPassword] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AUTH_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as StoredHash;
        if (parsed?.hash && parsed?.salt && parsed?.iterations) {
          setHasPassword(true);
        }
      }
    } catch {
      // ignore corrupted auth data
    } finally {
      setAuthLoading(false);
    }
  }, []);

  const handleSetupSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setAuthError(null);

    if (setupPassword.length < 12) {
      setAuthError('Use at least 12 characters for your master password.');
      return;
    }

    if (setupPassword !== setupConfirmPassword) {
      setAuthError('Passwords do not match.');
      return;
    }

    try {
      setIsProcessing(true);
      const stored = await hashPassword(setupPassword);
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(stored));
      setHasPassword(true);
      setIsAuthenticated(true);
      setSetupPassword('');
      setSetupConfirmPassword('');
    } catch (error) {
      console.error('Failed to set up password', error);
      setAuthError('Something went wrong while saving your password. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleLoginSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setAuthError(null);

    try {
      setIsProcessing(true);
      const raw = localStorage.getItem(AUTH_STORAGE_KEY);
      if (!raw) {
        setHasPassword(false);
        setAuthError('No password is configured yet. Please set a master password.');
        return;
      }

      const stored = JSON.parse(raw) as StoredHash;
      const ok = await verifyPassword(loginPassword, stored);
      if (!ok) {
        setAuthError('Incorrect password.');
        return;
      }

      setIsAuthenticated(true);
      setLoginPassword('');
    } catch (error) {
      console.error('Login failed', error);
      setAuthError('Something went wrong during login. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setLoginPassword('');
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center px-4">
      {!isAuthenticated ? (
        <div className="w-full max-w-md bg-card border border-border rounded-2xl p-6 sm:p-8 shadow-lg space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                <Cloud size={20} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold">Secure Access</h1>
                <p className="text-xs text-muted-foreground">
                  Protect your FileVault with a master password.
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsAboutOpen(true)}
              className="text-xs"
            >
              About
            </Button>
          </div>

          <div className="space-y-4">
            {!hasPassword ? (
              <>
                <p className="text-sm text-muted-foreground">
                  Create a strong master password. This password is never sent to any server and
                  is only used locally to unlock your files on this device.
                </p>
                <form onSubmit={handleSetupSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium" htmlFor="setup-password">
                      Master password
                    </label>
                    <input
                      id="setup-password"
                      type="password"
                      required
                      minLength={12}
                      autoComplete="new-password"
                      className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                      value={setupPassword}
                      onChange={(e) => setSetupPassword(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium" htmlFor="setup-confirm">
                      Confirm password
                    </label>
                    <input
                      id="setup-confirm"
                      type="password"
                      required
                      minLength={12}
                      autoComplete="new-password"
                      className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                      value={setupConfirmPassword}
                      onChange={(e) => setSetupConfirmPassword(e.target.value)}
                    />
                  </div>
                  {authError && (
                    <p className="text-xs text-destructive">{authError}</p>
                  )}
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isProcessing}
                  >
                    {isProcessing ? 'Securing…' : 'Set master password'}
                  </Button>
                  <p className="text-[11px] text-muted-foreground">
                    Warning: If you forget this password, there is no way to recover it. You will
                    need to clear your browser data to reset FileVault.
                  </p>
                </form>
              </>
            ) : (
              <>
                <p className="text-sm text-muted-foreground">
                  Enter your master password to unlock FileVault on this device.
                </p>
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium" htmlFor="login-password">
                      Master password
                    </label>
                    <input
                      id="login-password"
                      type="password"
                      required
                      autoComplete="current-password"
                      className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                    />
                  </div>
                  {authError && (
                    <p className="text-xs text-destructive">{authError}</p>
                  )}
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isProcessing}
                  >
                    {isProcessing ? 'Unlocking…' : 'Unlock'}
                  </Button>
                  <p className="text-[11px] text-muted-foreground">
                    Your password is verified locally using modern cryptography (PBKDF2 + SHA-256)
                    and is never sent over the network.
                  </p>
                </form>
              </>
            )}
          </div>
        </div>
      ) : (
        <>
          {/* File Manager Section */}
          <section id="files" className="py-8 px-4 sm:px-6 lg:px-8 w-full">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                    <Cloud size={18} className="text-white" />
                  </div>
                  <span className="font-semibold text-sm text-muted-foreground">
                    FileVault (unlocked)
                  </span>
                </div>
                <Button variant="outline" size="sm" onClick={handleLogout}>
                  Lock
                </Button>
              </div>
              <div className="bg-card/50 backdrop-blur-sm border border-border rounded-2xl p-6 sm:p-8">
                <FileManager />
              </div>
            </div>
          </section>
        </>
      )}

      {/* About Dialog */}
      <Dialog open={isAboutOpen} onOpenChange={setIsAboutOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                <Cloud size={18} className="text-white" />
              </div>
              About FileVault
            </DialogTitle>
            <DialogDescription>
              A modern, dark-themed file manager for your browser
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              FileVault is a fully functional file management application that runs entirely 
              in your browser. It uses localStorage to persist your files and folders, 
              meaning your data never leaves your device.
            </p>
            
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Keyboard Shortcuts</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Ctrl/Cmd + U</span>
                  <span className="text-muted-foreground">Upload files</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Ctrl/Cmd + N</span>
                  <span className="text-muted-foreground">New folder</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Backspace</span>
                  <span className="text-muted-foreground">Go back</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Double-click</span>
                  <span className="text-muted-foreground">Open folder</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Supported File Types</h4>
              <p className="text-sm text-muted-foreground">
                Images, Videos, Audio, Documents, Archives, Code files, and more.
              </p>
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button onClick={() => setIsAboutOpen(false)}>Got it</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
