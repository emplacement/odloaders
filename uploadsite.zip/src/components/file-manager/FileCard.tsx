import { useState, useRef } from 'react';
import type { FileItem } from '@/types/file';
import { FileIcon } from './FileIcon';
import {
  MoreVertical,
  Edit2,
  Trash2,
  FolderOpen,
  Download,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface FileCardProps {
  file: FileItem;
  formatFileSize: (bytes: number) => string;
  onNavigate: (folderId: string) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, newName: string) => void;
  onDownload?: (file: FileItem) => void;
}

export const FileCard: React.FC<FileCardProps> = ({
  file,
  formatFileSize,
  onNavigate,
  onDelete,
  onRename,
  onDownload,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [newName, setNewName] = useState(file.name);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleDoubleClick = () => {
    if (file.type === 'folder') {
      onNavigate(file.id);
    }
  };

  const handleRename = () => {
    if (newName.trim() && newName !== file.name) {
      onRename(file.id, newName.trim());
    }
    setIsRenameDialogOpen(false);
  };

  const handleDelete = () => {
    onDelete(file.id);
    setIsDeleteDialogOpen(false);
  };

  const handleDownload = () => {
    if (file.type === 'file' && file.content) {
      const link = document.createElement('a');
      link.href = file.content;
      link.download = file.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    onDownload?.(file);
  };

  const formatDate = (timestamp: number): string => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <>
      <div
        ref={cardRef}
        onDoubleClick={handleDoubleClick}
        className="group relative bg-card hover:bg-muted/50 border border-border rounded-xl p-4 transition-all duration-200 hover:shadow-lg hover:border-primary/30 cursor-pointer animate-scale-in"
      >
        {/* Context Menu */}
        <DropdownMenu open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <DropdownMenuTrigger asChild>
            <button
              onClick={(e) => e.stopPropagation()}
              className="absolute top-2 right-2 p-1.5 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-muted transition-opacity"
            >
              <MoreVertical size={16} className="text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            {file.type === 'folder' && (
              <DropdownMenuItem onClick={() => onNavigate(file.id)}>
                <FolderOpen size={16} className="mr-2" />
                Open
              </DropdownMenuItem>
            )}
            {file.type === 'file' && (
              <DropdownMenuItem onClick={handleDownload}>
                <Download size={16} className="mr-2" />
                Download
              </DropdownMenuItem>
            )}
            <DropdownMenuItem onClick={() => setIsRenameDialogOpen(true)}>
              <Edit2 size={16} className="mr-2" />
              Rename
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => setIsDeleteDialogOpen(true)}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 size={16} className="mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* File Icon */}
        <div className="flex flex-col items-center">
          <div className="w-20 h-20 flex items-center justify-center mb-3">
            {file.type === 'file' && file.mimeType?.startsWith('image/') && file.content ? (
              <img
                src={file.content}
                alt={file.name}
                className="w-full h-full object-cover rounded-lg"
              />
            ) : (
              <FileIcon
                type={file.type}
                mimeType={file.mimeType}
                size={56}
              />
            )}
          </div>

          {/* File Name */}
          <p
            className="text-sm font-medium text-center truncate w-full mb-1"
            title={file.name}
          >
            {file.name}
          </p>

          {/* File Info */}
          <p className="text-xs text-muted-foreground">
            {file.type === 'folder'
              ? 'Folder'
              : formatFileSize(file.size || 0)}
            {' • '}
            {formatDate(file.createdAt)}
          </p>
        </div>
      </div>

      {/* Rename Dialog */}
      <Dialog open={isRenameDialogOpen} onOpenChange={setIsRenameDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Rename {file.type === 'folder' ? 'Folder' : 'File'}</DialogTitle>
            <DialogDescription>
              Enter a new name for "{file.name}"
            </DialogDescription>
          </DialogHeader>
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleRename()}
            autoFocus
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRenameDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleRename}>Rename</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete {file.type === 'folder' ? 'Folder' : 'File'}</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{file.name}"?
              {file.type === 'folder' && ' This will delete all contents inside.'}
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
