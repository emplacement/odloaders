// FileIcon component - no React import needed
import {
  Folder,
  File,
  FileImage,
  FileVideo,
  FileAudio,
  FileText,
  FileCode,
  FileArchive,
  FileSpreadsheet,
  FileType,
  FilePieChart,
} from 'lucide-react';

interface FileIconProps {
  mimeType?: string;
  type: 'file' | 'folder';
  size?: number;
  className?: string;
}

export const FileIcon: React.FC<FileIconProps> = ({
  mimeType,
  type,
  size = 48,
  className = '',
}) => {
  if (type === 'folder') {
    return (
      <Folder
        size={size}
        className={`text-indigo-400 ${className}`}
        strokeWidth={1.5}
      />
    );
  }

  const getIcon = () => {
    if (!mimeType) return <File size={size} className={className} />;

    if (mimeType.startsWith('image/')) {
      return <FileImage size={size} className={`text-purple-400 ${className}`} />;
    }

    if (mimeType.startsWith('video/')) {
      return <FileVideo size={size} className={`text-red-400 ${className}`} />;
    }

    if (mimeType.startsWith('audio/')) {
      return <FileAudio size={size} className={`text-orange-400 ${className}`} />;
    }

    if (mimeType.includes('pdf')) {
      return <FileText size={size} className={`text-red-500 ${className}`} />;
    }

    if (mimeType.includes('word') || mimeType.includes('document') || mimeType.includes('msword')) {
      return <FileType size={size} className={`text-blue-400 ${className}`} />;
    }

    if (mimeType.includes('excel') || mimeType.includes('sheet') || mimeType.includes('csv')) {
      return <FileSpreadsheet size={size} className={`text-green-400 ${className}`} />;
    }

    if (mimeType.includes('powerpoint') || mimeType.includes('presentation')) {
      return <FilePieChart size={size} className={`text-orange-500 ${className}`} />;
    }

    if (mimeType.includes('zip') || mimeType.includes('rar') || mimeType.includes('7z') || mimeType.includes('archive')) {
      return <FileArchive size={size} className={`text-yellow-400 ${className}`} />;
    }

    if (mimeType.includes('code') || 
        mimeType.includes('javascript') || 
        mimeType.includes('typescript') || 
        mimeType.includes('json') ||
        mimeType.includes('html') ||
        mimeType.includes('css') ||
        mimeType.includes('text/')) {
      return <FileCode size={size} className={`text-cyan-400 ${className}`} />;
    }

    return <File size={size} className={`text-muted-foreground ${className}`} />;
  };

  return getIcon();
};
