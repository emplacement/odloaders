import type { ViewMode, SortBy, SortOrder, FileFilter } from '@/types/file';
import {
  Search,
  Grid3X3,
  List,
  FolderPlus,
  Upload,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Filter,
  Image,
  FileText,
  Video,
  Music,
  Folder,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';

interface ToolbarProps {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  sortBy: SortBy;
  setSortBy: (by: SortBy) => void;
  sortOrder: SortOrder;
  setSortOrder: (order: SortOrder) => void;
  filter: FileFilter;
  setFilter: (filter: FileFilter) => void;
  onCreateFolder: () => void;
  onUpload: () => void;
  fileCount: number;
  folderCount: number;
  totalSize: string;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  viewMode,
  setViewMode,
  sortBy,
  setSortBy,
  sortOrder,
  setSortOrder,
  filter,
  setFilter,
  onCreateFolder,
  onUpload,
  fileCount,
  folderCount,
  totalSize,
}) => {
  const hasActiveFilters = filter.search || filter.type !== 'all';

  const clearFilters = () => {
    setFilter({ search: '', type: 'all' });
  };

  const getSortLabel = (by: SortBy): string => {
    switch (by) {
      case 'name': return 'Name';
      case 'date': return 'Date';
      case 'size': return 'Size';
      case 'type': return 'Type';
      default: return 'Name';
    }
  };

  const getFilterLabel = (type: FileFilter['type']): string => {
    switch (type) {
      case 'all': return 'All Files';
      case 'images': return 'Images';
      case 'documents': return 'Documents';
      case 'videos': return 'Videos';
      case 'audio': return 'Audio';
      case 'folders': return 'Folders';
      default: return 'All Files';
    }
  };

  return (
    <div className="space-y-4">
      {/* Main Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
          />
          <Input
            value={filter.search}
            onChange={(e) => setFilter({ ...filter, search: e.target.value })}
            placeholder="Search files..."
            className="pl-10"
          />
          {filter.search && (
            <button
              onClick={() => setFilter({ ...filter, search: '' })}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* Filter Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="flex-shrink-0">
                <Filter size={16} className="mr-2" />
                <span className="hidden sm:inline">{getFilterLabel(filter.type)}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => setFilter({ ...filter, type: 'all' })}>
                <Filter size={16} className="mr-2" />
                All Files
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setFilter({ ...filter, type: 'images' })}>
                <Image size={16} className="mr-2" />
                Images
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter({ ...filter, type: 'documents' })}>
                <FileText size={16} className="mr-2" />
                Documents
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter({ ...filter, type: 'videos' })}>
                <Video size={16} className="mr-2" />
                Videos
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter({ ...filter, type: 'audio' })}>
                <Music size={16} className="mr-2" />
                Audio
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter({ ...filter, type: 'folders' })}>
                <Folder size={16} className="mr-2" />
                Folders
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Sort Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="flex-shrink-0">
                <ArrowUpDown size={16} className="mr-2" />
                <span className="hidden sm:inline">{getSortLabel(sortBy)}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => setSortBy('name')}>
                Name
                {sortBy === 'name' && (
                  <ArrowUp size={14} className="ml-auto" />
                )}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('date')}>
                Date
                {sortBy === 'date' && (
                  <ArrowUp size={14} className="ml-auto" />
                )}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('size')}>
                Size
                {sortBy === 'size' && (
                  <ArrowUp size={14} className="ml-auto" />
                )}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('type')}>
                Type
                {sortBy === 'type' && (
                  <ArrowUp size={14} className="ml-auto" />
                )}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}>
                {sortOrder === 'asc' ? (
                  <>
                    <ArrowUp size={16} className="mr-2" />
                    Ascending
                  </>
                ) : (
                  <>
                    <ArrowDown size={16} className="mr-2" />
                    Descending
                  </>
                )}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* View Mode Toggle */}
          <div className="flex items-center border rounded-lg overflow-hidden flex-shrink-0">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 transition-colors ${
                viewMode === 'grid'
                  ? 'bg-primary text-primary-foreground'
                  : 'hover:bg-muted'
              }`}
              title="Grid view"
            >
              <Grid3X3 size={18} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 transition-colors ${
                viewMode === 'list'
                  ? 'bg-primary text-primary-foreground'
                  : 'hover:bg-muted'
              }`}
              title="List view"
            >
              <List size={18} />
            </button>
          </div>

          {/* Create Folder */}
          <Button
            variant="outline"
            size="sm"
            onClick={onCreateFolder}
            className="flex-shrink-0"
          >
            <FolderPlus size={16} className="mr-2" />
            <span className="hidden sm:inline">New Folder</span>
          </Button>

          {/* Upload */}
          <Button size="sm" onClick={onUpload} className="flex-shrink-0">
            <Upload size={16} className="mr-2" />
            <span className="hidden sm:inline">Upload</span>
          </Button>
        </div>
      </div>

      {/* Stats & Filters Bar */}
      <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
        <span>{folderCount} folder{folderCount !== 1 ? 's' : ''}</span>
        <span>•</span>
        <span>{fileCount} file{fileCount !== 1 ? 's' : ''}</span>
        <span>•</span>
        <span>{totalSize}</span>
        
        {hasActiveFilters && (
          <>
            <span>•</span>
            <button
              onClick={clearFilters}
              className="flex items-center gap-1 text-primary hover:underline"
            >
              Clear filters
              <X size={14} />
            </button>
          </>
        )}

        {filter.type !== 'all' && (
          <Badge variant="secondary" className="ml-2">
            {getFilterLabel(filter.type)}
          </Badge>
        )}
      </div>
    </div>
  );
};
