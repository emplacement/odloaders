import { useState } from 'react';
import type { FileItem } from '@/types/file';
import { FileIcon } from './FileIcon';
import {
  MoreVertical,
  Edit2,
  Trash2,
  FolderOpen,
  Download,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface FileListItemProps {
  file: FileItem;
  formatFileSize: (bytes: number) => string;
  onNavigate: (folderId: string) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, newName: string) => void;
}

export const FileListItem: React.FC<FileListItemProps> = ({
  file,
  formatFileSize,
  onNavigate,
  onDelete,
  onRename,
}) => {
  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [newName, setNewName] = useState(file.name);

  const handleDoubleClick = () => {
    if (file.type === 'folder') {
      onNavigate(file.id);
    }
  };

  const handleRename = () => {
    if (newName.trim() && newName !== file.name) {
      onRename(file.id, newName.trim());
    }
    setIsRenameDialogOpen(false);
  };

  const handleDelete = () => {
    onDelete(file.id);
    setIsDeleteDialogOpen(false);
  };

  const handleDownload = () => {
    if (file.type === 'file' && file.content) {
      const link = document.createElement('a');
      link.href = file.content;
      link.download = file.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const formatDate = (timestamp: number): string => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const getFileType = (): string => {
    if (file.type === 'folder') return 'Folder';
    if (!file.mimeType) return 'File';
    
    const extension = file.name.split('.').pop()?.toUpperCase();
    if (extension) return `${extension} File`;
    
    return 'File';
  };

  return (
    <>
      <div
        onDoubleClick={handleDoubleClick}
        className="group flex items-center gap-4 p-3 hover:bg-muted/50 border-b border-border last:border-b-0 cursor-pointer transition-colors animate-slide-up"
      >
        {/* Icon */}
        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center">
          {file.type === 'file' && file.mimeType?.startsWith('image/') && file.content ? (
            <img
              src={file.content}
              alt={file.name}
              className="w-10 h-10 object-cover rounded"
            />
          ) : (
            <FileIcon
              type={file.type}
              mimeType={file.mimeType}
              size={24}
            />
          )}
        </div>

        {/* Name */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate" title={file.name}>
            {file.name}
          </p>
        </div>

        {/* Type */}
        <div className="hidden sm:block w-32 flex-shrink-0">
          <p className="text-sm text-muted-foreground">{getFileType()}</p>
        </div>

        {/* Size */}
        <div className="hidden md:block w-24 flex-shrink-0 text-right">
          <p className="text-sm text-muted-foreground">
            {file.type === 'folder' ? '--' : formatFileSize(file.size || 0)}
          </p>
        </div>

        {/* Date */}
        <div className="hidden lg:block w-32 flex-shrink-0 text-right">
          <p className="text-sm text-muted-foreground">
            {formatDate(file.createdAt)}
          </p>
        </div>

        {/* Actions */}
        <div className="flex-shrink-0 w-10">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                onClick={(e) => e.stopPropagation()}
                className="p-2 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-muted transition-opacity"
              >
                <MoreVertical size={16} className="text-muted-foreground" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {file.type === 'folder' && (
                <DropdownMenuItem onClick={() => onNavigate(file.id)}>
                  <FolderOpen size={16} className="mr-2" />
                  Open
                </DropdownMenuItem>
              )}
              {file.type === 'file' && (
                <DropdownMenuItem onClick={handleDownload}>
                  <Download size={16} className="mr-2" />
                  Download
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => setIsRenameDialogOpen(true)}>
                <Edit2 size={16} className="mr-2" />
                Rename
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => setIsDeleteDialogOpen(true)}
                className="text-destructive focus:text-destructive"
              >
                <Trash2 size={16} className="mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Rename Dialog */}
      <Dialog open={isRenameDialogOpen} onOpenChange={setIsRenameDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Rename {file.type === 'folder' ? 'Folder' : 'File'}</DialogTitle>
            <DialogDescription>
              Enter a new name for "{file.name}"
            </DialogDescription>
          </DialogHeader>
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleRename()}
            autoFocus
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRenameDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleRename}>Rename</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete {file.type === 'folder' ? 'Folder' : 'File'}</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{file.name}"?
              {file.type === 'folder' && ' This will delete all contents inside.'}
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
