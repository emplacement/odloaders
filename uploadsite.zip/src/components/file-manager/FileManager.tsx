import { useState, useCallback, useEffect } from 'react';
import { useFileStorage } from '@/hooks/useFileStorage';
import { FileCard } from './FileCard';
import { FileListItem } from './FileListItem';
import { UploadZone } from './UploadZone';
import { CreateFolderDialog } from './CreateFolderDialog';
import { Breadcrumbs } from './Breadcrumbs';
import { Toolbar } from './Toolbar';
import { EmptyState } from './EmptyState';
import { Button } from '@/components/ui/button';
import { ArrowLeft, HardDrive } from 'lucide-react';

export const FileManager: React.FC = () => {
  const {
    currentFolderId,
    viewMode,
    sortBy,
    sortOrder,
    filter,
    setViewMode,
    setSortBy,
    setSortOrder,
    setFilter,
    createFolder,
    uploadMultipleFiles,
    deleteFile,
    renameFile,
    navigateToFolder,
    navigateUp,
    getCurrentFiles,
    getBreadcrumbs,
    getTotalSize,
    getFileCount,
    getFolderCount,
    formatFileSize,
    isLoaded,
  } = useFileStorage();

  const [isUploadZoneOpen, setIsUploadZoneOpen] = useState(false);
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false);

  const currentFiles = getCurrentFiles();
  const breadcrumbs = getBreadcrumbs();
  const totalSize = formatFileSize(getTotalSize());
  const fileCount = getFileCount();
  const folderCount = getFolderCount();

  const handleUpload = useCallback(async (files: FileList) => {
    try {
      await uploadMultipleFiles(files);
    } catch (error) {
      console.error('Upload failed:', error);
    }
  }, [uploadMultipleFiles]);

  const handleCreateFolder = useCallback((name: string) => {
    createFolder(name);
  }, [createFolder]);

  const handleClearFilters = useCallback(() => {
    setFilter({ search: '', type: 'all' });
  }, [setFilter]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + U for upload
      if ((e.ctrlKey || e.metaKey) && e.key === 'u') {
        e.preventDefault();
        setIsUploadZoneOpen(true);
      }
      // Ctrl/Cmd + N for new folder
      if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
        e.preventDefault();
        setIsCreateFolderOpen(true);
      }
      // Backspace for navigate up
      if (e.key === 'Backspace' && !e.target) {
        e.preventDefault();
        navigateUp();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigateUp]);

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  const showEmptyState = currentFiles.length === 0;
  const hasNoResults = showEmptyState && (filter.search || filter.type !== 'all');
  const isRootEmpty = showEmptyState && !currentFolderId && !filter.search && filter.type === 'all';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {currentFolderId && (
            <Button
              variant="outline"
              size="icon"
              onClick={navigateUp}
              className="flex-shrink-0"
              title="Go back"
            >
              <ArrowLeft size={18} />
            </Button>
          )}
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <HardDrive className="text-primary" size={28} />
              My Files
            </h1>
            <div className="mt-1">
              <Breadcrumbs
                breadcrumbs={breadcrumbs}
                onNavigate={navigateToFolder}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <Toolbar
        viewMode={viewMode}
        setViewMode={setViewMode}
        sortBy={sortBy}
        setSortBy={setSortBy}
        sortOrder={sortOrder}
        setSortOrder={setSortOrder}
        filter={filter}
        setFilter={setFilter}
        onCreateFolder={() => setIsCreateFolderOpen(true)}
        onUpload={() => setIsUploadZoneOpen(true)}
        fileCount={fileCount}
        folderCount={folderCount}
        totalSize={totalSize}
      />

      {/* File Grid/List */}
      {showEmptyState ? (
        <EmptyState
          type={hasNoResults ? 'no-results' : isRootEmpty ? 'upload' : 'empty'}
          onUpload={() => setIsUploadZoneOpen(true)}
          onCreateFolder={() => setIsCreateFolderOpen(true)}
          onClearFilters={hasNoResults ? handleClearFilters : undefined}
        />
      ) : (
        <div className="animate-fade-in">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {currentFiles.map((file, index) => (
                <div
                  key={file.id}
                  style={{ animationDelay: `${index * 0.05}s` }}
                  className="animate-scale-in"
                >
                  <FileCard
                    file={file}
                    formatFileSize={formatFileSize}
                    onNavigate={navigateToFolder}
                    onDelete={deleteFile}
                    onRename={renameFile}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              {/* List Header */}
              <div className="flex items-center gap-4 p-3 bg-muted/50 border-b border-border text-sm font-medium text-muted-foreground">
                <div className="flex-shrink-0 w-10">Type</div>
                <div className="flex-1">Name</div>
                <div className="hidden sm:block w-32">Type</div>
                <div className="hidden md:block w-24 text-right">Size</div>
                <div className="hidden lg:block w-32 text-right">Date</div>
                <div className="flex-shrink-0 w-10"></div>
              </div>
              
              {/* List Items */}
              <div>
                {currentFiles.map((file, index) => (
                  <div
                    key={file.id}
                    style={{ animationDelay: `${index * 0.03}s` }}
                  >
                    <FileListItem
                      file={file}
                      formatFileSize={formatFileSize}
                      onNavigate={navigateToFolder}
                      onDelete={deleteFile}
                      onRename={renameFile}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Upload Zone */}
      <UploadZone
        isOpen={isUploadZoneOpen}
        onClose={() => setIsUploadZoneOpen(false)}
        onUpload={handleUpload}
      />

      {/* Create Folder Dialog */}
      <CreateFolderDialog
        isOpen={isCreateFolderOpen}
        onClose={() => setIsCreateFolderOpen(false)}
        onCreate={handleCreateFolder}
      />
    </div>
  );
};
