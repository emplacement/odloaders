// EmptyState component - no React import needed
import { FolderOpen, Upload, FolderPlus, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface EmptyStateProps {
  type: 'empty' | 'no-results' | 'upload';
  onUpload?: () => void;
  onCreateFolder?: () => void;
  onClearFilters?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  type,
  onUpload,
  onCreateFolder,
  onClearFilters,
}) => {
  if (type === 'no-results') {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
        <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-4">
          <Search size={40} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold mb-2">No results found</h3>
        <p className="text-muted-foreground max-w-md mb-4">
          We couldn&apos;t find any files matching your search. Try adjusting your filters or search terms.
        </p>
        {onClearFilters && (
          <Button variant="outline" onClick={onClearFilters}>
            Clear Filters
          </Button>
        )}
      </div>
    );
  }

  if (type === 'upload') {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
        <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-4 animate-pulse-glow">
          <Upload size={40} className="text-primary" />
        </div>
        <h3 className="text-lg font-semibold mb-2">Upload your first file</h3>
        <p className="text-muted-foreground max-w-md mb-6">
          Drag and drop files here or click the upload button to get started.
        </p>
        <div className="flex gap-3">
          {onUpload && (
            <Button onClick={onUpload}>
              <Upload size={18} className="mr-2" />
              Upload Files
            </Button>
          )}
          {onCreateFolder && (
            <Button variant="outline" onClick={onCreateFolder}>
              <FolderPlus size={18} className="mr-2" />
              Create Folder
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-4">
        <FolderOpen size={40} className="text-muted-foreground" />
      </div>
      <h3 className="text-lg font-semibold mb-2">This folder is empty</h3>
      <p className="text-muted-foreground max-w-md mb-6">
        Get started by uploading files or creating a new folder.
      </p>
      <div className="flex gap-3">
        {onUpload && (
          <Button onClick={onUpload}>
            <Upload size={18} className="mr-2" />
            Upload Files
          </Button>
        )}
        {onCreateFolder && (
          <Button variant="outline" onClick={onCreateFolder}>
            <FolderPlus size={18} className="mr-2" />
            Create Folder
          </Button>
        )}
      </div>
    </div>
  );
};
