import { Fragment } from 'react';
import type { FileItem } from '@/types/file';
import { Home, ChevronRight } from 'lucide-react';

interface BreadcrumbsProps {
  breadcrumbs: FileItem[];
  onNavigate: (folderId: string | null) => void;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  breadcrumbs,
  onNavigate,
}) => {
  return (
    <nav className="flex items-center gap-1 text-sm">
      <button
        onClick={() => onNavigate(null)}
        className="flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
      >
        <Home size={16} />
        <span className="hidden sm:inline">Home</span>
      </button>
      
      {breadcrumbs.map((folder, index) => (
        <Fragment key={folder.id}>
          <ChevronRight size={16} className="text-muted-foreground flex-shrink-0" />
          <button
            onClick={() => onNavigate(folder.id)}
            className={`px-2 py-1 rounded-md hover:bg-muted transition-colors truncate max-w-[150px] sm:max-w-[200px]
              ${index === breadcrumbs.length - 1 
                ? 'text-foreground font-medium' 
                : 'text-muted-foreground hover:text-foreground'
              }
            `}
            title={folder.name}
          >
            {folder.name}
          </button>
        </Fragment>
      ))}
    </nav>
  );
};
