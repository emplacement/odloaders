import { useState, useRef, useCallback } from 'react';
import { Upload, X, File as FileIcon, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

interface UploadZoneProps {
  onUpload: (files: FileList) => Promise<void>;
  isOpen: boolean;
  onClose: () => void;
}

interface UploadFile {
  file: File;
  id: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  onUpload,
  isOpen,
  onClose,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      addFilesToQueue(files);
    }
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      addFilesToQueue(files);
    }
  }, []);

  const addFilesToQueue = (files: FileList) => {
    const newFiles: UploadFile[] = Array.from(files).map((file) => ({
      file,
      id: Math.random().toString(36).substring(2, 15),
      progress: 0,
      status: 'pending',
    }));
    
    setUploadFiles((prev) => [...prev, ...newFiles]);
  };

  const removeFile = (id: string) => {
    setUploadFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const startUpload = async () => {
    if (uploadFiles.length === 0) return;
    
    setIsUploading(true);
    
    // Simulate progress for each file
    const filesToUpload = uploadFiles.filter((f) => f.status === 'pending');
    
    for (const uploadFile of filesToUpload) {
      setUploadFiles((prev) =>
        prev.map((f) =>
          f.id === uploadFile.id ? { ...f, status: 'uploading' } : f
        )
      );

      // Simulate progress
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise((resolve) => setTimeout(resolve, 50));
        setUploadFiles((prev) =>
          prev.map((f) =>
            f.id === uploadFile.id ? { ...f, progress } : f
          )
        );
      }

      setUploadFiles((prev) =>
        prev.map((f) =>
          f.id === uploadFile.id ? { ...f, status: 'completed', progress: 100 } : f
        )
      );
    }

    // Actually upload the files
    const dataTransfer = new DataTransfer();
    filesToUpload.forEach((f) => dataTransfer.items.add(f.file));
    
    try {
      await onUpload(dataTransfer.files);
    } catch (error) {
      console.error('Upload failed:', error);
    }

    setIsUploading(false);
    
    // Close after a brief delay to show completion
    setTimeout(() => {
      setUploadFiles([]);
      onClose();
    }, 1000);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl mx-4">
        {/* Main Upload Area */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`
            relative bg-card border-2 border-dashed rounded-2xl p-8 transition-all duration-300
            ${isDragOver 
              ? 'border-primary bg-primary/10 scale-[1.02]' 
              : 'border-border hover:border-muted-foreground/50'
            }
          `}
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-lg hover:bg-muted transition-colors"
            disabled={isUploading}
          >
            <X size={20} className="text-muted-foreground" />
          </button>

          {/* Upload Content */}
          {uploadFiles.length === 0 ? (
            <div className="text-center py-12">
              <div
                className={`
                  w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center
                  transition-all duration-300
                  ${isDragOver ? 'bg-primary/20 scale-110' : 'bg-muted'}
                `}
              >
                <Upload
                  size={40}
                  className={`transition-colors ${isDragOver ? 'text-primary' : 'text-muted-foreground'}`}
                />
              </div>
              
              <h3 className="text-xl font-semibold mb-2">
                {isDragOver ? 'Drop files here' : 'Drag & drop files here'}
              </h3>
              <p className="text-muted-foreground mb-6">
                or click to browse from your computer
              </p>
              
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
                className="gradient-border"
              >
                Select Files
              </Button>
              
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">
                  {isUploading ? 'Uploading...' : 'Ready to upload'}
                </h3>
                <span className="text-sm text-muted-foreground">
                  {uploadFiles.length} file{uploadFiles.length !== 1 ? 's' : ''}
                </span>
              </div>

              {/* File List */}
              <div className="max-h-64 overflow-y-auto space-y-2 pr-2">
                {uploadFiles.map((uploadFile) => (
                  <div
                    key={uploadFile.id}
                    className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg"
                  >
                    <div className="w-10 h-10 flex items-center justify-center bg-muted rounded-lg">
                      <FileIcon size={20} className="text-muted-foreground" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {uploadFile.file.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatFileSize(uploadFile.file.size)}
                      </p>
                      
                      {uploadFile.status === 'uploading' && (
                        <Progress
                          value={uploadFile.progress}
                          className="h-1 mt-2"
                        />
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {uploadFile.status === 'completed' && (
                        <Check size={20} className="text-neon-green" />
                      )}
                      {uploadFile.status === 'uploading' && (
                        <Loader2 size={20} className="animate-spin text-primary" />
                      )}
                      {uploadFile.status === 'pending' && !isUploading && (
                        <button
                          onClick={() => removeFile(uploadFile.id)}
                          className="p-1.5 rounded hover:bg-muted-foreground/20 transition-colors"
                        >
                          <X size={16} className="text-muted-foreground" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="flex-1"
                >
                  Add More
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <Button
                  onClick={startUpload}
                  disabled={isUploading || uploadFiles.every((f) => f.status !== 'pending')}
                  className="flex-1"
                >
                  {isUploading ? (
                    <>
                      <Loader2 size={18} className="mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload size={18} className="mr-2" />
                      Upload All
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}

          {/* Supported Formats */}
          {uploadFiles.length === 0 && (
            <p className="text-center text-xs text-muted-foreground mt-6">
              Supports: Images, Videos, Documents, Audio, and more
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
