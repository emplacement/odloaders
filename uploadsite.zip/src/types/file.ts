export interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  size?: number;
  mimeType?: string;
  content?: string; // Base64 for files
  parentId: string | null;
  createdAt: number;
  updatedAt: number;
  children?: string[]; // For folders - array of child IDs
}

export interface FileUploadProgress {
  fileId: string;
  fileName: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
}

export interface FolderStructure {
  [key: string]: FileItem;
}

export type ViewMode = 'grid' | 'list';

export type SortBy = 'name' | 'date' | 'size' | 'type';

export type SortOrder = 'asc' | 'desc';

export interface FileFilter {
  search: string;
  type: 'all' | 'images' | 'documents' | 'videos' | 'audio' | 'folders';
}
