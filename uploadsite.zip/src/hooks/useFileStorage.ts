import { useState, useEffect, useCallback } from 'react';
import type { FileItem, FolderStructure, ViewMode, SortBy, SortOrder, FileFilter } from '@/types/file';

const STORAGE_KEY = 'filevault_data';

const generateId = () => Math.random().toString(36).substring(2, 15);

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const getFileIcon = (mimeType?: string): string => {
  if (!mimeType) return 'file';
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  if (mimeType.includes('pdf')) return 'pdf';
  if (mimeType.includes('word') || mimeType.includes('document')) return 'word';
  if (mimeType.includes('excel') || mimeType.includes('sheet')) return 'excel';
  if (mimeType.includes('powerpoint') || mimeType.includes('presentation')) return 'powerpoint';
  if (mimeType.includes('zip') || mimeType.includes('rar') || mimeType.includes('7z')) return 'archive';
  if (mimeType.includes('code') || mimeType.includes('javascript') || mimeType.includes('typescript') || mimeType.includes('json')) return 'code';
  return 'file';
};

export const useFileStorage = () => {
  const [files, setFiles] = useState<FolderStructure>({});
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortBy, setSortBy] = useState<SortBy>('name');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [filter, setFilter] = useState<FileFilter>({ search: '', type: 'all' });
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setFiles(parsed);
      } catch (e) {
        console.error('Failed to parse stored files:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Save to localStorage whenever files change
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(files));
    }
  }, [files, isLoaded]);

  const getBreadcrumbs = useCallback((): FileItem[] => {
    const breadcrumbs: FileItem[] = [];
    let currentId: string | null = currentFolderId;
    
    while (currentId) {
      const folder = files[currentId];
      if (folder) {
        breadcrumbs.unshift(folder);
        currentId = folder.parentId;
      } else {
        break;
      }
    }
    
    return breadcrumbs;
  }, [files, currentFolderId]);

  const getCurrentFiles = useCallback((): FileItem[] => {
    const currentFiles = Object.values(files).filter(
      (file) => file.parentId === currentFolderId
    );

    // Apply filter
    let filtered = currentFiles;
    
    if (filter.search) {
      const searchLower = filter.search.toLowerCase();
      filtered = filtered.filter((file) =>
        file.name.toLowerCase().includes(searchLower)
      );
    }

    if (filter.type !== 'all') {
      if (filter.type === 'folders') {
        filtered = filtered.filter((file) => file.type === 'folder');
      } else {
        filtered = filtered.filter((file) => {
          if (file.type === 'folder') return false;
          const icon = getFileIcon(file.mimeType);
          return icon === filter.type;
        });
      }
    }

    // Apply sorting
    const sorted = [...filtered].sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'date':
          comparison = a.createdAt - b.createdAt;
          break;
        case 'size':
          comparison = (a.size || 0) - (b.size || 0);
          break;
        case 'type':
          comparison = (a.mimeType || '').localeCompare(b.mimeType || '');
          break;
      }
      
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    // Folders first
    return sorted.sort((a, b) => {
      if (a.type === 'folder' && b.type !== 'folder') return -1;
      if (a.type !== 'folder' && b.type === 'folder') return 1;
      return 0;
    });
  }, [files, currentFolderId, filter, sortBy, sortOrder]);

  const createFolder = useCallback((name: string): FileItem => {
    const newFolder: FileItem = {
      id: generateId(),
      name,
      type: 'folder',
      parentId: currentFolderId,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      children: [],
    };

    setFiles((prev) => ({
      ...prev,
      [newFolder.id]: newFolder,
    }));

    return newFolder;
  }, [currentFolderId]);

  const uploadFile = useCallback(async (file: globalThis.File): Promise<FileItem> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        const newFile: FileItem = {
          id: generateId(),
          name: file.name,
          type: 'file',
          size: file.size,
          mimeType: file.type,
          content: e.target?.result as string,
          parentId: currentFolderId,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        setFiles((prev) => ({
          ...prev,
          [newFile.id]: newFile,
        }));

        resolve(newFile);
      };

      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }, [currentFolderId]);

  const uploadMultipleFiles = useCallback(async (fileList: FileList): Promise<FileItem[]> => {
    const uploadPromises = Array.from(fileList).map((file) => uploadFile(file));
    return Promise.all(uploadPromises);
  }, [uploadFile]);

  const deleteFile = useCallback((id: string) => {
    setFiles((prev) => {
      const newFiles = { ...prev };
      
      // Recursive delete for folders
      const deleteRecursive = (fileId: string) => {
        const file = newFiles[fileId];
        if (file?.type === 'folder' && file.children) {
          file.children.forEach(deleteRecursive);
        }
        delete newFiles[fileId];
      };
      
      deleteRecursive(id);
      return newFiles;
    });
  }, []);

  const renameFile = useCallback((id: string, newName: string) => {
    setFiles((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        name: newName,
        updatedAt: Date.now(),
      },
    }));
  }, []);

  const moveFile = useCallback((id: string, newParentId: string | null) => {
    setFiles((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        parentId: newParentId,
        updatedAt: Date.now(),
      },
    }));
  }, []);

  const navigateToFolder = useCallback((folderId: string | null) => {
    setCurrentFolderId(folderId);
  }, []);

  const navigateUp = useCallback(() => {
    if (currentFolderId) {
      const currentFolder = files[currentFolderId];
      setCurrentFolderId(currentFolder?.parentId || null);
    }
  }, [currentFolderId, files]);

  const getFileById = useCallback((id: string): FileItem | undefined => {
    return files[id];
  }, [files]);

  const getTotalSize = useCallback((): number => {
    return Object.values(files).reduce((total, file) => {
      return total + (file.size || 0);
    }, 0);
  }, [files]);

  const getFileCount = useCallback((): number => {
    return Object.values(files).filter((f) => f.type === 'file').length;
  }, [files]);

  const getFolderCount = useCallback((): number => {
    return Object.values(files).filter((f) => f.type === 'folder').length;
  }, [files]);

  return {
    files,
    currentFolderId,
    viewMode,
    sortBy,
    sortOrder,
    filter,
    isLoaded,
    setViewMode,
    setSortBy,
    setSortOrder,
    setFilter,
    createFolder,
    uploadFile,
    uploadMultipleFiles,
    deleteFile,
    renameFile,
    moveFile,
    navigateToFolder,
    navigateUp,
    getCurrentFiles,
    getBreadcrumbs,
    getFileById,
    getTotalSize,
    getFileCount,
    getFolderCount,
    formatFileSize,
    getFileIcon,
  };
};
