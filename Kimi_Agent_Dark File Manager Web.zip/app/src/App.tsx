import { useState, useEffect } from 'react';
import { FileManager } from '@/components/file-manager';
import { Button } from '@/components/ui/button';
import {
  HardDrive,
  Info,
  Github,
  Twitter,
  Menu,
  X,
  Cloud,
  Shield,
  Zap,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

function App() {
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Handle scroll for navbar styling
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Files', href: '#files', icon: HardDrive },
    { label: 'Features', href: '#features', icon: Zap },
    { label: 'Security', href: '#security', icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-background/80 backdrop-blur-xl border-b border-border'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <a href="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center group-hover:shadow-glow transition-shadow">
                <Cloud size={24} className="text-white" />
              </div>
              <span className="text-xl font-bold text-gradient">FileVault</span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsAboutOpen(true)}
                className="text-muted-foreground"
              >
                <Info size={20} />
              </Button>
              <Button
                variant="default"
                size="sm"
                className="bg-gradient-to-r from-indigo-500 to-cyan-500 hover:shadow-glow transition-shadow"
              >
                Get Started
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-background/95 backdrop-blur-xl border-b border-border animate-slide-up">
            <div className="px-4 py-4 space-y-2">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <link.icon size={20} />
                  {link.label}
                </a>
              ))}
              <div className="pt-4 border-t border-border">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setIsAboutOpen(true);
                  }}
                >
                  <Info size={18} className="mr-2" />
                  About
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl animate-pulse-glow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1s' }} />
        </div>

        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-muted border border-border mb-6 animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
            <span className="text-sm text-muted-foreground">Free & Open Source</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 animate-slide-up">
            Your files,{' '}
            <span className="text-gradient">your way</span>
          </h1>

          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            A beautiful, dark-themed file manager that runs entirely in your browser. 
            Upload, organize, and manage your files with ease.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <Button
              size="lg"
              className="bg-gradient-to-r from-indigo-500 to-cyan-500 hover:shadow-glow-lg transition-shadow"
              onClick={() => document.getElementById('files')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <HardDrive size={20} className="mr-2" />
              Open File Manager
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => setIsAboutOpen(true)}
            >
              <Info size={20} className="mr-2" />
              Learn More
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto mt-16 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <div className="text-center">
              <p className="text-2xl sm:text-3xl font-bold text-gradient">100%</p>
              <p className="text-sm text-muted-foreground">Private</p>
            </div>
            <div className="text-center">
              <p className="text-2xl sm:text-3xl font-bold text-gradient">0</p>
              <p className="text-sm text-muted-foreground">Tracking</p>
            </div>
            <div className="text-center">
              <p className="text-2xl sm:text-3xl font-bold text-gradient">∞</p>
              <p className="text-sm text-muted-foreground">Storage</p>
            </div>
          </div>
        </div>
      </section>

      {/* File Manager Section */}
      <section id="files" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="bg-card/50 backdrop-blur-sm border border-border rounded-2xl p-6 sm:p-8">
            <FileManager />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 sm:px-6 lg:px-8 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Features</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Everything you need to manage your files efficiently
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Zap,
                title: 'Lightning Fast',
                description: 'Instant uploads and downloads with no server delays. Everything happens locally in your browser.',
                color: 'text-yellow-400',
              },
              {
                icon: Shield,
                title: '100% Private',
                description: 'Your files never leave your device. No cloud storage, no tracking, complete privacy.',
                color: 'text-green-400',
              },
              {
                icon: Cloud,
                title: 'Unlimited Storage',
                description: 'Store as many files as your browser allows. Limited only by your device storage.',
                color: 'text-blue-400',
              },
            ].map((feature, index) => (
              <div
                key={feature.title}
                className="group p-6 bg-card border border-border rounded-xl hover:border-primary/30 transition-all hover:shadow-glow"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className={`w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <feature.icon size={24} className={feature.color} />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security Section */}
      <section id="security" className="py-16 px-4 sm:px-6 lg:px-8 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">Your Data Stays Yours</h2>
              <p className="text-muted-foreground mb-6">
                FileVault uses your browser&apos;s local storage to save files. This means:
              </p>
              <ul className="space-y-4">
                {[
                  'No account required - start using immediately',
                  'No data sent to any server - completely offline',
                  'Files persist between sessions via localStorage',
                  'Clear your browser data to remove all files',
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-neon-green/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 rounded-full bg-neon-green" />
                    </div>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-cyan-500/20 rounded-2xl blur-2xl" />
              <div className="relative bg-card border border-border rounded-2xl p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                    <Shield size={32} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Privacy First</h3>
                    <p className="text-muted-foreground">Zero-knowledge architecture</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">Data Collection</span>
                    <span className="text-sm font-medium text-neon-green">None</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">Server Uploads</span>
                    <span className="text-sm font-medium text-neon-green">None</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">Third-party Access</span>
                    <span className="text-sm font-medium text-neon-green">None</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                <Cloud size={18} className="text-white" />
              </div>
              <span className="font-bold text-gradient">FileVault</span>
            </div>

            <p className="text-sm text-muted-foreground text-center">
              Built with React, Tailwind CSS & shadcn/ui. Open source on GitHub.
            </p>

            <div className="flex items-center gap-4">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              >
                <Github size={20} />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              >
                <Twitter size={20} />
              </a>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
            <p>© {new Date().getFullYear()} FileVault. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* About Dialog */}
      <Dialog open={isAboutOpen} onOpenChange={setIsAboutOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                <Cloud size={18} className="text-white" />
              </div>
              About FileVault
            </DialogTitle>
            <DialogDescription>
              A modern, dark-themed file manager for your browser
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              FileVault is a fully functional file management application that runs entirely 
              in your browser. It uses localStorage to persist your files and folders, 
              meaning your data never leaves your device.
            </p>
            
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Keyboard Shortcuts</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Ctrl/Cmd + U</span>
                  <span className="text-muted-foreground">Upload files</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Ctrl/Cmd + N</span>
                  <span className="text-muted-foreground">New folder</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Backspace</span>
                  <span className="text-muted-foreground">Go back</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted rounded">
                  <span>Double-click</span>
                  <span className="text-muted-foreground">Open folder</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Supported File Types</h4>
              <p className="text-sm text-muted-foreground">
                Images, Videos, Audio, Documents, Archives, Code files, and more.
              </p>
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button onClick={() => setIsAboutOpen(false)}>Got it</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
