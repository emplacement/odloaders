use axum::{
    Json, Router,
    body::Body,
    extract::State,
    http::{HeaderMap, HeaderValue, StatusCode, header},
    response::{Html, IntoResponse, Response},
    routing::{get, post},
};
use serde::Deserialize;
use serde_json::json;

use crate::AppState;

const AUTH_HTML: &str = include_str!("auth_panel.html");
const DASHBOARD_HTML: &str = include_str!("dashboard.html");

const SESSION_COOKIE: &str = "nl_session";

pub fn router(state: AppState) -> Router {
    Router::new()
        .route("/register", get(auth_page))
        .route("/login", get(auth_page))
        .route("/dashboard", get(dashboard_page))
        .route("/api/register", post(do_register))
        .route("/api/login", post(do_login))
        .route("/api/logout", post(do_logout))
        .route("/api/me", get(me))
        .route("/api/me/avatar", get(me_avatar).post(upload_avatar))
        .with_state(state)
}

async fn auth_page() -> Html<&'static str> {
    Html(AUTH_HTML)
}

async fn dashboard_page() -> Html<&'static str> {
    Html(DASHBOARD_HTML)
}

// ── cookie helpers ──

fn read_session_cookie(headers: &HeaderMap) -> Option<String> {
    let raw = headers.get(header::COOKIE)?.to_str().ok()?;
    for part in raw.split(';') {
        let part = part.trim();
        if let Some(value) = part.strip_prefix(&format!("{SESSION_COOKIE}=")) {
            return Some(value.to_string());
        }
    }
    None
}

fn set_session_cookie_header(session_id: &str) -> String {
    format!(
        "{SESSION_COOKIE}={session_id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000"
    )
}

fn clear_session_cookie_header() -> String {
    format!("{SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0")
}

async fn current_account(
    state: &AppState,
    headers: &HeaderMap,
) -> Option<crate::accounts::Account> {
    let session_id = read_session_cookie(headers)?;
    let account_id = state.sessions.account_id(&session_id).await?;
    state.accounts.find_by_id(&account_id).await
}

// ── handlers ──

#[derive(Deserialize)]
struct RegisterBody {
    username: String,
    password: String,
    invite_code: String,
}

async fn do_register(State(state): State<AppState>, Json(body): Json<RegisterBody>) -> Response {
    let username = body.username.trim();
    let invite_code = body.invite_code.trim();

    if username.is_empty() || username.len() > 32 {
        return err(StatusCode::BAD_REQUEST, "username must be 1-32 characters");
    }
    if body.password.len() < 8 {
        return err(StatusCode::BAD_REQUEST, "password must be at least 8 characters");
    }
    if invite_code.is_empty() {
        return err(StatusCode::BAD_REQUEST, "invite code required");
    }

    if !state.invites.is_valid_unused(invite_code).await {
        return err(StatusCode::BAD_REQUEST, "invalid or already-used invite code");
    }

    let password_hash = crate::accounts::hash_password(&body.password);
    let account = match state
        .accounts
        .register(username.to_string(), password_hash)
        .await
    {
        Ok(account) => account,
        Err(e) => return err(StatusCode::CONFLICT, &e.to_string()),
    };

    if let Err(e) = state.invites.consume(invite_code, &account.username).await {
        tracing::error!("[public] failed to mark invite consumed: {e}");
    }

    let session_id = state.sessions.create(&account.id).await;
    let mut response = Json(json!({ "ok": true })).into_response();
    response.headers_mut().insert(
        header::SET_COOKIE,
        HeaderValue::from_str(&set_session_cookie_header(&session_id)).unwrap(),
    );
    response
}

#[derive(Deserialize)]
struct LoginBody {
    username: String,
    password: String,
}

async fn do_login(State(state): State<AppState>, Json(body): Json<LoginBody>) -> Response {
    let Some(account) = state.accounts.find_by_username(body.username.trim()).await else {
        return err(StatusCode::UNAUTHORIZED, "invalid username or password");
    };
    let Some(hash) = &account.password_hash else {
        return err(StatusCode::UNAUTHORIZED, "invalid username or password");
    };
    if !crate::accounts::verify_password(&body.password, hash) {
        return err(StatusCode::UNAUTHORIZED, "invalid username or password");
    }
    if !account.enabled {
        return err(StatusCode::FORBIDDEN, "account disabled");
    }

    let session_id = state.sessions.create(&account.id).await;
    let mut response = Json(json!({ "ok": true })).into_response();
    response.headers_mut().insert(
        header::SET_COOKIE,
        HeaderValue::from_str(&set_session_cookie_header(&session_id)).unwrap(),
    );
    response
}

async fn do_logout(State(state): State<AppState>, headers: HeaderMap) -> Response {
    if let Some(session_id) = read_session_cookie(&headers) {
        state.sessions.destroy(&session_id).await;
    }
    let mut response = Json(json!({ "ok": true })).into_response();
    response.headers_mut().insert(
        header::SET_COOKIE,
        HeaderValue::from_str(&clear_session_cookie_header()).unwrap(),
    );
    response
}

async fn me(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let Some(account) = current_account(&state, &headers).await else {
        return err(StatusCode::UNAUTHORIZED, "not logged in");
    };
    let avatar_path = crate::utils::avatar_file_path(state.storage.root_dir(), &account.id);
    let has_avatar = tokio::fs::metadata(&avatar_path).await.is_ok();

    Json(json!({
        "username": account.username,
        "token": account.token,
        "enabled": account.enabled,
        "has_avatar": has_avatar,
    }))
    .into_response()
}

async fn me_avatar(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let Some(account) = current_account(&state, &headers).await else {
        return err(StatusCode::UNAUTHORIZED, "not logged in");
    };
    let path = crate::utils::avatar_file_path(state.storage.root_dir(), &account.id);
    let Ok(bytes) = tokio::fs::read(&path).await else {
        return StatusCode::NOT_FOUND.into_response();
    };
    let content_type = crate::utils::sniff_image_content_type(&bytes);
    Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, content_type)
        .body(Body::from(bytes))
        .unwrap_or_else(|_| StatusCode::INTERNAL_SERVER_ERROR.into_response())
}

#[derive(Deserialize)]
struct AvatarBody {
    /// Raw base64, or a data URL (`data:image/png;base64,...`) — both accepted.
    image_base64: String,
}

async fn upload_avatar(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(body): Json<AvatarBody>,
) -> Response {
    let Some(account) = current_account(&state, &headers).await else {
        return err(StatusCode::UNAUTHORIZED, "not logged in");
    };

    let raw = body
        .image_base64
        .split_once("base64,")
        .map(|(_, b)| b)
        .unwrap_or(&body.image_base64);

    use base64::Engine as _;
    let bytes = match base64::engine::general_purpose::STANDARD.decode(raw.trim()) {
        Ok(b) => b,
        Err(_) => return err(StatusCode::BAD_REQUEST, "invalid base64 image data"),
    };

    if bytes.is_empty() || bytes.len() > 5 * 1024 * 1024 {
        return err(StatusCode::BAD_REQUEST, "image must be non-empty and under 5MB");
    }

    let content_type = crate::utils::sniff_image_content_type(&bytes);
    if content_type == "application/octet-stream" {
        return err(StatusCode::BAD_REQUEST, "unrecognized image format (use PNG, JPEG, GIF, or WebP)");
    }

    let path = crate::utils::avatar_file_path(state.storage.root_dir(), &account.id);
    if let Some(parent) = path.parent() {
        if let Err(e) = tokio::fs::create_dir_all(parent).await {
            tracing::error!("[public] failed to create avatars dir: {e}");
            return err(StatusCode::INTERNAL_SERVER_ERROR, "failed to save avatar");
        }
    }
    if let Err(e) = tokio::fs::write(&path, &bytes).await {
        tracing::error!("[public] failed to write avatar: {e}");
        return err(StatusCode::INTERNAL_SERVER_ERROR, "failed to save avatar");
    }

    Json(json!({ "ok": true })).into_response()
}

fn err(status: StatusCode, message: &str) -> Response {
    let body = Body::from(json!({ "error": message }).to_string());
    Response::builder()
        .status(status)
        .header(header::CONTENT_TYPE, "application/json")
        .body(body)
        .unwrap_or_else(|_| StatusCode::INTERNAL_SERVER_ERROR.into_response())
}
