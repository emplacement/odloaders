use std::collections::HashMap;
use std::sync::Arc;

use tokio::sync::RwLock;
use uuid::Uuid;

/// In-memory session_id -> account_id map. Sessions are lost on server restart
/// (users just log in again); nothing here is persisted to disk.
#[derive(Clone)]
pub struct SessionStore {
    inner: Arc<RwLock<HashMap<String, String>>>,
}

impl SessionStore {
    pub fn new() -> Self {
        SessionStore {
            inner: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub async fn create(&self, account_id: &str) -> String {
        let session_id = format!("{}{}", Uuid::new_v4().simple(), Uuid::new_v4().simple());
        self.inner
            .write()
            .await
            .insert(session_id.clone(), account_id.to_string());
        session_id
    }

    pub async fn account_id(&self, session_id: &str) -> Option<String> {
        self.inner.read().await.get(session_id).cloned()
    }

    pub async fn destroy(&self, session_id: &str) {
        self.inner.write().await.remove(session_id);
    }
}
