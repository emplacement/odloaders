use std::path::PathBuf;
use std::sync::Arc;

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Account {
    pub id: String,
    pub username: String,
    pub token: String,
    pub enabled: bool,
    #[serde(default)]
    pub note: String,
    pub created_at: String,
    /// Unix timestamp (seconds) after which the token stops working. None = never expires.
    #[serde(default)]
    pub expires_at: Option<i64>,
    #[serde(default)]
    pub last_connected_at: Option<String>,
    /// Set only for accounts created through public self-registration.
    /// Admin-created accounts (token-only) leave this as None.
    #[serde(default)]
    pub password_hash: Option<String>,
}

#[derive(Default, Serialize, Deserialize)]
struct AccountsFile {
    #[serde(default)]
    accounts: Vec<Account>,
}

pub struct AccountStore {
    path: PathBuf,
    inner: Arc<RwLock<Vec<Account>>>,
}

impl Clone for AccountStore {
    fn clone(&self) -> Self {
        AccountStore {
            path: self.path.clone(),
            inner: Arc::clone(&self.inner),
        }
    }
}

impl AccountStore {
    pub async fn load_or_init(root: &std::path::Path) -> Result<Self> {
        let path = root.join("accounts.json");
        let accounts = if path.exists() {
            let json = tokio::fs::read_to_string(&path)
                .await
                .with_context(|| format!("failed to read {}", path.display()))?;
            let file: AccountsFile =
                serde_json::from_str(&json).with_context(|| "failed to parse accounts.json")?;
            file.accounts
        } else {
            Vec::new()
        };

        Ok(AccountStore {
            path,
            inner: Arc::new(RwLock::new(accounts)),
        })
    }

    async fn persist(&self, accounts: &[Account]) -> Result<()> {
        let file = AccountsFile {
            accounts: accounts.to_vec(),
        };
        let json = serde_json::to_vec_pretty(&file).context("failed to serialize accounts")?;
        let tmp = self.path.with_extension("json.tmp");
        if let Some(parent) = self.path.parent() {
            tokio::fs::create_dir_all(parent).await.ok();
        }
        tokio::fs::write(&tmp, &json)
            .await
            .with_context(|| format!("failed to write {}", tmp.display()))?;
        tokio::fs::rename(&tmp, &self.path)
            .await
            .with_context(|| format!("failed to rename into {}", self.path.display()))
    }

    pub async fn list(&self) -> Vec<Account> {
        let mut accounts = self.inner.read().await.clone();
        accounts.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        accounts
    }

    pub async fn create(
        &self,
        username: String,
        note: String,
        expires_days: Option<i64>,
    ) -> Result<Account> {
        let mut accounts = self.inner.write().await;
        let expires_at = expires_days
            .filter(|d| *d > 0)
            .map(|d| unix_now() + d * 86400);

        let account = Account {
            id: Uuid::new_v4().to_string(),
            username,
            token: generate_secret(),
            enabled: true,
            note,
            created_at: crate::storage::now_iso(),
            expires_at,
            last_connected_at: None,
            password_hash: None,
        };
        accounts.push(account.clone());
        self.persist(&accounts).await?;
        Ok(account)
    }

    /// Creates an account through public self-registration (username + password, gated by an invite).
    /// Fails if the username is already taken (case-insensitive).
    pub async fn register(&self, username: String, password_hash: String) -> Result<Account> {
        let mut accounts = self.inner.write().await;
        if accounts
            .iter()
            .any(|a| a.username.eq_ignore_ascii_case(&username))
        {
            anyhow::bail!("username already taken");
        }

        let account = Account {
            id: Uuid::new_v4().to_string(),
            username,
            token: generate_secret(),
            enabled: true,
            note: String::new(),
            created_at: crate::storage::now_iso(),
            expires_at: None,
            last_connected_at: None,
            password_hash: Some(password_hash),
        };
        accounts.push(account.clone());
        self.persist(&accounts).await?;
        Ok(account)
    }

    pub async fn find_by_username(&self, username: &str) -> Option<Account> {
        self.inner
            .read()
            .await
            .iter()
            .find(|a| a.username.eq_ignore_ascii_case(username))
            .cloned()
    }

    pub async fn find_by_id(&self, id: &str) -> Option<Account> {
        self.inner.read().await.iter().find(|a| a.id == id).cloned()
    }

    pub async fn set_enabled(&self, id: &str, enabled: bool) -> Result<bool> {
        let mut accounts = self.inner.write().await;
        let Some(acc) = accounts.iter_mut().find(|a| a.id == id) else {
            return Ok(false);
        };
        acc.enabled = enabled;
        self.persist(&accounts).await?;
        Ok(true)
    }

    pub async fn delete(&self, id: &str) -> Result<bool> {
        let mut accounts = self.inner.write().await;
        let before = accounts.len();
        accounts.retain(|a| a.id != id);
        let changed = accounts.len() != before;
        if changed {
            self.persist(&accounts).await?;
        }
        Ok(changed)
    }

    /// Returns the matching account if the token is known, enabled, and not expired.
    pub async fn validate(&self, token: &str) -> Option<Account> {
        let accounts = self.inner.read().await;
        let acc = accounts.iter().find(|a| a.token == token)?;
        if !acc.enabled {
            return None;
        }
        if let Some(exp) = acc.expires_at {
            if exp <= unix_now() {
                return None;
            }
        }
        Some(acc.clone())
    }

    pub async fn touch_last_connected(&self, id: &str) {
        let mut accounts = self.inner.write().await;
        if let Some(acc) = accounts.iter_mut().find(|a| a.id == id) {
            acc.last_connected_at = Some(crate::storage::now_iso());
            let _ = self.persist(&accounts).await;
        }
    }
}

fn unix_now() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}

/// Generates a random 64-char hex secret (two v4 UUIDs concatenated, no dashes).
pub fn generate_secret() -> String {
    format!("{}{}", Uuid::new_v4().simple(), Uuid::new_v4().simple())
}

// ── Passwords ──
// Salted + iterated SHA-256. Not as strong as argon2/bcrypt, but avoids pulling
// in a heavier dependency tree, and is fine given this isn't a high-value target.

const HASH_ITERATIONS: u32 = 100_000;

pub fn hash_password(password: &str) -> String {
    let salt = generate_secret();
    let hash = stretch(password, &salt);
    format!("{salt}${hash}")
}

pub fn verify_password(password: &str, stored: &str) -> bool {
    let Some((salt, expected_hex)) = stored.split_once('$') else {
        return false;
    };
    let actual_hex = stretch(password, salt);
    // constant-time-ish comparison
    actual_hex.len() == expected_hex.len()
        && actual_hex
            .bytes()
            .zip(expected_hex.bytes())
            .fold(0u8, |acc, (a, b)| acc | (a ^ b))
            == 0
}

fn stretch(password: &str, salt: &str) -> String {
    use sha2::{Digest, Sha256};

    let mut data = format!("{salt}:{password}").into_bytes();
    for _ in 0..HASH_ITERATIONS {
        let mut hasher = Sha256::new();
        hasher.update(&data);
        data = hasher.finalize().to_vec();
    }
    to_hex(&data)
}

fn to_hex(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push_str(&format!("{b:02x}"));
    }
    s
}

// ── Invites ──

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Invite {
    pub code: String,
    #[serde(default)]
    pub note: String,
    pub created_at: String,
    #[serde(default)]
    pub used_by_username: Option<String>,
    #[serde(default)]
    pub used_at: Option<String>,
}

#[derive(Default, Serialize, Deserialize)]
struct InvitesFile {
    #[serde(default)]
    invites: Vec<Invite>,
}

pub struct InviteStore {
    path: PathBuf,
    inner: Arc<RwLock<Vec<Invite>>>,
}

impl Clone for InviteStore {
    fn clone(&self) -> Self {
        InviteStore {
            path: self.path.clone(),
            inner: Arc::clone(&self.inner),
        }
    }
}

impl InviteStore {
    pub async fn load_or_init(root: &std::path::Path) -> Result<Self> {
        let path = root.join("invites.json");
        let invites = if path.exists() {
            let json = tokio::fs::read_to_string(&path)
                .await
                .with_context(|| format!("failed to read {}", path.display()))?;
            let file: InvitesFile =
                serde_json::from_str(&json).with_context(|| "failed to parse invites.json")?;
            file.invites
        } else {
            Vec::new()
        };

        Ok(InviteStore {
            path,
            inner: Arc::new(RwLock::new(invites)),
        })
    }

    async fn persist(&self, invites: &[Invite]) -> Result<()> {
        let file = InvitesFile {
            invites: invites.to_vec(),
        };
        let json = serde_json::to_vec_pretty(&file).context("failed to serialize invites")?;
        let tmp = self.path.with_extension("json.tmp");
        if let Some(parent) = self.path.parent() {
            tokio::fs::create_dir_all(parent).await.ok();
        }
        tokio::fs::write(&tmp, &json)
            .await
            .with_context(|| format!("failed to write {}", tmp.display()))?;
        tokio::fs::rename(&tmp, &self.path)
            .await
            .with_context(|| format!("failed to rename into {}", self.path.display()))
    }

    pub async fn list(&self) -> Vec<Invite> {
        let mut invites = self.inner.read().await.clone();
        invites.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        invites
    }

    pub async fn create(&self, note: String) -> Result<Invite> {
        let mut invites = self.inner.write().await;
        let invite = Invite {
            code: generate_invite_code(),
            note,
            created_at: crate::storage::now_iso(),
            used_by_username: None,
            used_at: None,
        };
        invites.push(invite.clone());
        self.persist(&invites).await?;
        Ok(invite)
    }

    pub async fn delete(&self, code: &str) -> Result<bool> {
        let mut invites = self.inner.write().await;
        let before = invites.len();
        invites.retain(|i| i.code != code);
        let changed = invites.len() != before;
        if changed {
            self.persist(&invites).await?;
        }
        Ok(changed)
    }

    /// Marks an unused invite as consumed by `username`. Returns false if the
    /// code doesn't exist or was already used.
    pub async fn consume(&self, code: &str, username: &str) -> Result<bool> {
        let mut invites = self.inner.write().await;
        let Some(invite) = invites.iter_mut().find(|i| i.code == code) else {
            return Ok(false);
        };
        if invite.used_by_username.is_some() {
            return Ok(false);
        }
        invite.used_by_username = Some(username.to_string());
        invite.used_at = Some(crate::storage::now_iso());
        self.persist(&invites).await?;
        Ok(true)
    }

    pub async fn is_valid_unused(&self, code: &str) -> bool {
        self.inner
            .read()
            .await
            .iter()
            .any(|i| i.code == code && i.used_by_username.is_none())
    }
}

fn generate_invite_code() -> String {
    let raw = Uuid::new_v4().simple().to_string().to_uppercase();
    let chars: Vec<char> = raw.chars().take(12).collect();
    chars
        .chunks(4)
        .map(|c| c.iter().collect::<String>())
        .collect::<Vec<_>>()
        .join("-")
}
