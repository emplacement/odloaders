pub fn preview_text(s: &str, max: usize) -> String {
    let mut p: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        p.push_str("...");
    }
    p
}

pub fn unix_timestamp() -> i32 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i32
}

pub fn now_iso() -> String {
    crate::storage::now_iso()
}

pub fn extract_json_str(json: &str, path: &[&str]) -> Option<String> {
    let value: serde_json::Value = serde_json::from_str(json).ok()?;
    let mut current: &serde_json::Value = &value;
    for key in path {
        current = current.get(*key)?;
    }
    current.as_str().map(|s| s.to_string())
}

/// Sniffs common image formats from magic bytes. Falls back to a generic type.
pub fn sniff_image_content_type(bytes: &[u8]) -> &'static str {
    if bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
        "image/png"
    } else if bytes.starts_with(b"\xff\xd8\xff") {
        "image/jpeg"
    } else if bytes.starts_with(b"GIF87a") || bytes.starts_with(b"GIF89a") {
        "image/gif"
    } else if bytes.len() >= 12 && &bytes[0..4] == b"RIFF" && &bytes[8..12] == b"WEBP" {
        "image/webp"
    } else {
        "application/octet-stream"
    }
}

/// Path where a given account's custom avatar (if any) is stored on disk.
pub fn avatar_file_path(data_root: &std::path::Path, account_id: &str) -> std::path::PathBuf {
    data_root.join("avatars").join(format!("{account_id}.bin"))
}
